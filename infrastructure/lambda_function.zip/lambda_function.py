import json

def lambda_handler(event, context):
    """
    Lambda function for IAM Dashboard API
    """
    
    # Get HTTP method and path
    http_method = event.get('httpMethod', 'GET')
    path = event.get('path', '/')
    
    # Handle different endpoints
    if path == '/health':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'status': 'healthy',
                'message': 'IAM Dashboard API is running'
            })
        }
    
    elif path == '/api/scan-results':
        if http_method == 'GET':
            return get_scan_results()
        elif http_method == 'POST':
            return create_scan_result(event)
    
    else:
        return {
            'statusCode': 404,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Not found'})
        }

def get_scan_results():
    """Get all scan results"""
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'scan_results': [],
            'message': 'No scan results yet'
        })
    }

def create_scan_result(event):
    """Create a new scan result"""
    try:
        body = json.loads(event.get('body', '{}'))
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Scan result created',
                'data': body
            })
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }